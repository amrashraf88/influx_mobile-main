import 'package:adzmavall/features/influencer_orders/presentation/models/influencer_order_models.dart';
import 'package:adzmavall/features/influencer_orders/presentation/widgets/orders_adaptive_image.dart';
import 'package:adzmavall/utils/appcolors.dart';
import 'package:adzmavall/utils/imageassets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class OrderCard extends StatelessWidget {
  const OrderCard({super.key, required this.order, required this.onTap});

  final InfluencerOrder order;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white,
      borderRadius: BorderRadius.circular(18.r),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18.r),
        child: Container(
          padding: EdgeInsets.all(14.w),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18.r),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.035),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _OrderLogo(asset: order.logoAsset),
                  SizedBox(width: 14.w),
                  Expanded(child: _OrderSummary(order: order)),
                ],
              ),
              SizedBox(height: 14.h),
              Divider(color: const Color(0xFFE5E7EB), height: 1.h),
              SizedBox(height: 14.h),
              _OrderMetaRow(order: order),
              SizedBox(height: 14.h),
              OrderProgressBars(order: order, height: 8.h),
            ],
          ),
        ),
      ),
    );
  }
}

class OrderProgressBars extends StatelessWidget {
  const OrderProgressBars({
    super.key,
    required this.order,
    required this.height,
  });

  final InfluencerOrder order;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List<Widget>.generate(4, (int index) {
        final bool active = index < order.status.progressStep;
        return Expanded(
          child: Container(
            height: height,
            margin: EdgeInsetsDirectional.only(end: index == 3 ? 0 : 8.w),
            decoration: BoxDecoration(
              color: active ? order.status.color : const Color(0xFFE5E7EB),
              borderRadius: BorderRadius.circular(8.r),
            ),
          ),
        );
      }),
    );
  }
}

class OrderStatusChip extends StatelessWidget {
  const OrderStatusChip({super.key, required this.order});

  final InfluencerOrder order;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: order.status.color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
            Icons.radio_button_checked,
            size: 12.sp,
            color: order.status.color,
          ),
          SizedBox(width: 4.w),
          Text(
            order.status.label,
            style: TextStyle(
              fontSize: 9.5.sp,
              fontWeight: FontWeight.w600,
              color: order.status.color,
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderSummary extends StatelessWidget {
  const _OrderSummary({required this.order});

  final InfluencerOrder order;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          order.clientName,
          style: TextStyle(
            fontSize: 15.sp,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        SizedBox(height: 4.h),
        Text(
          order.clientSubtitle,
          style: TextStyle(fontSize: 12.sp, color: AppColors.textSecondary),
        ),
        SizedBox(height: 9.h),
        OrderStatusChip(order: order),
        SizedBox(height: 10.h),
        Row(
          children: <Widget>[
            OrdersAdaptiveImage(
              source: order.platformIconAsset,
              width: 22.w,
              height: 22.w,
              fit: BoxFit.contain,
              fallback: Icon(Icons.music_note_rounded, size: 20.sp),
            ),
            const Spacer(),
            _RsCurrencyText(
              value: order.priceLabel,
              style: TextStyle(
                color: AppColors.brandBlue,
                fontSize: 15.sp,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _OrderMetaRow extends StatelessWidget {
  const _OrderMetaRow({required this.order});

  final InfluencerOrder order;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Text(
          'Delivery Date : ${order.deliveryDateLabel}',
          style: TextStyle(fontSize: 12.sp, color: AppColors.textSecondary),
        ),
        const Spacer(),
        Text(
          order.orderNumber,
          style: TextStyle(fontSize: 12.sp, color: AppColors.textSecondary),
        ),
      ],
    );
  }
}

class _RsCurrencyText extends StatelessWidget {
  const _RsCurrencyText({
    required this.value,
    required this.style,
  });

  final String value;
  final TextStyle style;

  @override
  Widget build(BuildContext context) {
    const String currencyText = 'ر.س';
    if (!value.contains(currencyText)) {
      return Text(value, style: style);
    }

    final String amountText = value.replaceAll(currencyText, '').trim();
    return Text.rich(
      TextSpan(
        children: <InlineSpan>[
          if (amountText.isNotEmpty) TextSpan(text: amountText, style: style),
          WidgetSpan(
            alignment: PlaceholderAlignment.middle,
            child: Padding(
              padding: EdgeInsetsDirectional.only(start: 4.w),
              child: OrdersAdaptiveImage(
                source: ImageAssets.rsIcon,
                width: 16,
                height: 16,
                fit: BoxFit.contain,
                fallback: Icon(
                  Icons.currency_exchange_rounded,
                  size: 16,
                  color: style.color,
                ),
              ),
            ),
          ),
        ],
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

class _OrderLogo extends StatelessWidget {
  const _OrderLogo({required this.asset});

  final String asset;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16.r),
      child: Container(
        width: 100.w,
        height: 128.h,
        color: const Color(0xFFF5F7FB),
        child: OrdersAdaptiveImage(
          source: asset,
          width: 100.w,
          height: 128.h,
          fit: BoxFit.cover,
          fallback: Center(
            child: Icon(
              Icons.storefront_rounded,
              color: AppColors.brandBlue,
              size: 34.sp,
            ),
          ),
        ),
      ),
    );
  }
}
