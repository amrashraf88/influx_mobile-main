import 'package:adzmavall/features/influencer_orders/presentation/cubit/influencer_orders_cubit.dart';
import 'package:adzmavall/features/influencer_orders/presentation/widgets/orders_filter_bar.dart';
import 'package:adzmavall/features/influencer_orders/presentation/widgets/orders_list.dart';
import 'package:adzmavall/features/influencer_orders/presentation/widgets/orders_search_row.dart';
import 'package:adzmavall/utils/appcolors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class InfluencerOrdersPage extends StatelessWidget {
  const InfluencerOrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<InfluencerOrdersCubit>(
      create: (_) => InfluencerOrdersCubit()..loadOrders(),
      child: Builder(
        builder: (BuildContext context) {
          final Locale locale = Localizations.localeOf(context);
          final bool isArabic = locale.languageCode == 'ar';
          return Directionality(
            textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
            child: SafeArea(
              bottom: false,
              child: Column(
                children: <Widget>[
                  SizedBox(height: 20.h),
                  Text(
                    'Manage Orders',
                    style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  const OrdersFilterBar(),
                  SizedBox(height: 16.h),
                  const OrdersSearchRow(),
                  SizedBox(height: 14.h),
                  const Expanded(child: OrdersList()),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
